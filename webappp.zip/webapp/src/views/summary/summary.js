import React, { useState } from 'react';
import { Table, Card, Button, Select } from 'antd';
import { DownloadOutlined } from '@ant-design/icons';
import './summary.css'
import DownloadForOfflineRoundedIcon from '@mui/icons-material/DownloadForOfflineRounded';
import { useNavigate } from 'react-router';

const { Option } = Select;

const PatientDetails = () => {
  const [selectedItems, setSelectedItems] = useState([]);
  const [showDetailpage, setshowDetailpage] = useState(false);
  const navigate = useNavigate()

  const OPTIONS = ['Apples', 'Nails', 'Bananas', 'Helicopters'];
  const filteredOptions = OPTIONS.filter((o) => !selectedItems.includes(o));

  const handleSelectChange = (value) => {
    console.log(`Selected value: ${value}`);
  };

  const handleButtonClick = () => {
    console.log('Button clicked');
  };

  const data = [
    {
      key: '1',
      name: 'Fernando Borrero',
      dob: '05/06/44',
      gender: 'Male',
      address: 'Unit 1 High 113-B, Deepak - 2 Setia',

    },
    {
      key: '2',
      name: 'Bryant, Arnold ',
      dob: '05/06/44',
      gender: 'Male',
      address: 'Unit 1 High 113-B, Deepak - 2 Setia',
    },
  ];
  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
      // render: (text, record) => (
      //   <span
      //     onClick={() => handleNameClick(record.name)}
      //     onKeyDown={(e) => handleNameKeyDown(e, record.name)}
      //     tabIndex={0}
      //     role="button"
      //     style={{ cursor: 'pointer', fontWeight: 600 }}
      //   >
      //     {text}
      //   </span>
      // ),
    },
    { title: 'Date of Birth', dataIndex: 'dob', key: 'dob' },
    { title: 'Gender', dataIndex: 'gender', key: 'gender' },
    { title: 'Address', dataIndex: 'address', key: 'address' },
    {
      title: 'Action', dataIndex: 'action',

      render: (text, y) => (
        <>
          <Button className='view_btn' onClick={handleCertificate}>view</Button>
        </>
      ),
    },
  ];

  const handleCertificate = () => {
    navigate('./certificate');
    navigate(0)
  }

  // const handleNameKeyDown = (e, name) => {
  //   // if (e.key === 'Enter') {
  //   //   handleNameClick(name);
  //   // }
  //   console.log(e, name)
  // };

  // const handleNameClick = (x, y) => {
  //   console.log(x, y)
  //   // setshowDetailpage(true)
  //   navigate('/certificate')
  // }

  const extraContent = (
    <div>
      <Select
        placeholder="Select Patient Name"
        style={{ marginRight: '8px', width: 200 }}
        onChange={handleSelectChange}
      >
        <Option value="Option 1">Fernando Borrero</Option>
        <Option value="Option 2">Bryant Arnold</Option>
      </Select>
      <Button
        type="primary"
        onClick={handleButtonClick}
        icon={<DownloadForOfflineRoundedIcon className='pdf_icon' />}
        size="medium"
        className='pdf_downlaod'
      >
        PDF
      </Button>
    </div>
  );
  const columnsDetails = [

    { title: 'Physician', dataIndex: 'physician', key: 'physician' },
    { title: 'Diagnosis', dataIndex: 'diagnosis', key: 'diagnosis' },
    { title: 'Blood Pressure', dataIndex: 'bloodPressure', key: 'bloodPressure' },
    { title: 'Temperature', dataIndex: 'temperature', key: 'temperature' },
    { title: 'Pulse', dataIndex: 'pulse', key: 'pulse' },
    { title: 'Respiration', dataIndex: 'respiration', key: 'respiration' },
    { title: 'Weight', dataIndex: 'weight', key: 'weight' },
    { title: 'Height', dataIndex: 'height', key: 'height' },
    { title: 'Symptoms', dataIndex: 'symptoms', key: 'symptoms' },
    { title: 'Pressure Ulcer', dataIndex: 'pressureUlcer', key: 'pressureUlcer' },
    { title: 'Gangrene', dataIndex: 'gangrene', key: 'gangrene' },
    {
      title: 'Transfer from Hospital',
      dataIndex: 'transferFromHospital',
      key: 'transferFromHospital',
    },
  ]
  const Detailsdata = [
    {
      key: '1',
      physician: 'Deepak',
      diagnosis: 'Essential (Primary) Hypertension',
      bloodPressure: '166/70*',
      temperature: '97.8',
      pulse: '98',
      respiration: '17',
      weight: '88',
      height: '124',
      symptoms: 'Muscle Weakness',
      pressureUlcer: 'No',
      gangrene: 'No',
      transferFromHospital: 'No',
    }
  ]
  return (
    <div>
      {showDetailpage ?
        <Card title="Clinical Summary" extra={extraContent}>
          <Table
            dataSource={Detailsdata}
            columns={columnsDetails}
            pagination={false}
            rowClassName={(record, index) => (index % 2 === 0 ? 'table-row-light' : 'table-row-dark')}
            className="striped-table"
          />
        </Card> :
        <Card title="Clinical Summary" extra={extraContent}>
          <Table
            dataSource={data}
            columns={columns}
            pagination={false}
            rowClassName={(record, index) => (index % 2 === 0 ? 'table-row-light' : 'table-row-dark')}
            className="striped-table"
          />
        </Card>}
    </div>
  );
};

export default PatientDetails;
