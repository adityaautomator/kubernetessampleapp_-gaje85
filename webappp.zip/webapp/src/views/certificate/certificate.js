import React, { useState } from 'react';
import './certificate.scss';
import { Card, Button, Grid } from 'antd';
import DownloadForOfflineRoundedIcon from '@mui/icons-material/DownloadForOfflineRounded';
import { Col, Divider, Row } from 'antd';


const Certificate = () => {
  const [isJumping, setIsJumping] = useState(false);
  const handleJump = () => {
    setIsJumping(true);
    setTimeout(() => {
      setIsJumping(false);
    }, 1000); // Set the duration of the animation here (in milliseconds)
  };

  const style = {
    background: '#fff',
  };

  return (
    <>
      <div className="certificate">
        <div className='name_btn'>
          <h2 className="certificate-title">Certificate of Summary</h2>
          <Button
            type="primary"
            icon={<DownloadForOfflineRoundedIcon className='pdf_icon' />}
            size="medium"
            className={`btn_pdf ${isJumping ? 'jump' : ''}`}
            onClick={handleJump}
          >
            PDF
          </Button>
        </div>

        <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section_patient">
                <h2 className="section-title">PATIENT DETAILS</h2>
                <p>Patient Name: Borrero Fernando</p>
                <p>DOB: 05-06-1994</p>
                <p>Gender: Male</p>
                <p>Physician: Deepak-2 Setai</p>
                <p>Room#Unit 1 High 113-B</p>
                <p>Admissions: Transfer from Hospital</p>
                <p>Admitting Diagnosis: Deepak - 2 Setai</p>
              </div>
            </div>
          </Col>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section_vitals">
                <h2 className="section-title">VITALS</h2>
                <p className='blood_pressure'>Most Recent Pulse: 97</p>
                <p>Most Recent Respiration: 18</p>
                <p>Most Recent Temperature: 98</p>
                <p className='blood_pressure'>Most Recent Blood Pressure: 120 / 70</p>
                <p>Most Recent Hr: 89</p>
                <p>Most Recent Blood Sugar: 112</p>
                <p>Weight (Lbs): 174.6</p>
              </div>
            </div>
          </Col>
        </Row>

        <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section_pharmacy">
                <h2 className="section-title">PHARMACY</h2>
                <p>Poly-Pharmacy: No</p>
              </div>
            </div>
          </Col>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section">
                <h2 className="section-title">REHAB</h2>
                <p>New Contractures: No</p>
                <p>Change In Adl: Yes</p>
                <p>Any Clinical Concern Documented By Pt/Ot/St: Yes</p>
              </div>
            </div>
          </Col>
        </Row>

        <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section">
                <h2 className="section-title">PHYSICAL EXAM</h2>
                <p>S/P Fall: No</p>
                <p>Rs: No</p>
                <p>Patients With Ongoing Iv Fluids: No</p>
                <p>Msk: No</p>
                <p>Heent: No</p>
                <p>Gu: No</p>
                <p>Cvs: No</p>
                <p>Abdomen: No</p>
                <p>Neuro: A&amp;O X2</p>
                <p>Skin Changes: Stage 2 Pressure Ulcer To Right Buttock</p>
              </div>
            </div>
          </Col>
          <Col className="gutter-row" span={12}>
            <div style={style}>
              <div className="section">
                <h2 className="section-title">SOCIAL WORK</h2>
                <p>Review Goc On Admissions: No</p>
                <p>Discharge Planning: No</p>
                <p>Molst Form Review Quarterly: No</p>
              </div>

              <div className="section_test">
                <h2 className="section-title">TEST</h2>
                <p>Labs, Radiology, Drr: No</p>
              </div>
            </div>
          </Col>
        </Row>

        <div className="section">
          <h2 className="section-title">NURSING / PROVIDER / CONSULTATION NOTES</h2>
          <p>Patients Recently Seen By Any Specialist/Consultant - To Review And Follow Up On The Consultant Recommendation: Yes</p>
          <p>Patients With New Infection And Isolation Orders: No</p>
          <p>
            Notes: Resident Was Seen By Wound Care Specialist Today For Initial Wound Consult For
            Stage 2 Pressure Ulcer To Right Buttock, Wound Size: 2.3C1.7C0.1 Cm, 100% Partial
            Thickness, Moderate Amount Of Serous Drainage, Treatment: Medihoney Paste With Foam
            Dressing. Treatment Order In Place, Will Continue To Monitor Wound And Provide Treatment.
          </p>
        </div>
      </div>
    </>
  );
};

export default Certificate;
