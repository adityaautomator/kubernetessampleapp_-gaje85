import React from 'react';

// material-ui
import { Card, CardContent, TextField } from '@mui/material';
import { textAlign } from '@mui/system';

const DateTimeFromPicker = ({
    todayDateString,
    handleDateTimeFromSelected
}) => {
    return (
        <Card
            sx={{
                mt: 3,
                mr: 1,
                width: '34%',
                textAlign: 'center'
            }}
        >
            <CardContent>
                <TextField
                    id="fromdatetime-local"
                    label="From Date & Time"
                    type="datetime-local"
                    defaultValue={todayDateString + 'T07:59:59'}
                    sx={{ width: 250 }}
                    InputLabelProps={{
                        shrink: true
                    }}
                    onChange={(e) => handleDateTimeFromSelected(e.target.value)}
                />
            </CardContent>
        </Card>
    );
};

const DateTimeToPicker = ({ todayDateString, handleDateTimeToSelected }) => {
    return (
        <Card
            sx={{
                mt: 3,
                ml: 1,
                width: '34%',
                textAlign: 'center'
            }}
        >
            <CardContent>
                <TextField
                    id="todatetime-local"
                    label="To Date & Time"
                    type="datetime-local"
                    defaultValue={todayDateString + 'T18:00:01'}
                    sx={{ width: 250 }}
                    InputLabelProps={{
                        shrink: true
                    }}
                    onChange={(e) => handleDateTimeToSelected(e.target.value)}
                />
            </CardContent>
        </Card>
    );
};

export { DateTimeFromPicker, DateTimeToPicker };
