import React from 'react';

// material-ui
import { Card, CardContent } from '@mui/material';

//project-imports
import HeapGraph from './HeapGraph';
import ReferenceObjectsGraph from './ReferenceObjectsGraph';
import FailedPromotionsGraph from './FailedPromotionsGraph';
import FailedEvacuationsGraph from './FailedEvacuationsGraph';

const Graphs = ({
    graphsToDisplay,

    fromDateTime,
    toDateTime
}) => {
    let displayHeapGraph = graphsToDisplay.includes('Heap');
    let displayReferenceObjectsGraph =
        graphsToDisplay.includes('Reference Objects');
    let displayFailedPromotionsGraph =
        graphsToDisplay.includes('Failed Promotions');
    let displayFailedEvacuationsGraph =
        graphsToDisplay.includes('Failed Evacuations');
    return (
        <Card
            sx={{
                mt: 5,
                width: '70%'
            }}
        >
            <CardContent>
                {displayHeapGraph ? (
                    <HeapGraph
                        fromDateTime={fromDateTime}
                        toDateTime={toDateTime}
                    />
                ) : (
                    <div></div>
                )}
                {/* <br /> */}
                {displayReferenceObjectsGraph ? (
                    <ReferenceObjectsGraph
                        fromDateTime={fromDateTime}
                        toDateTime={toDateTime}
                    />
                ) : (
                    <div></div>
                )}
                {/* <br /> */}
                {displayFailedPromotionsGraph ? (
                    <FailedPromotionsGraph
                        fromDateTime={fromDateTime}
                        toDateTime={toDateTime}
                    />
                ) : (
                    <div></div>
                )}
                {/* <br /> */}
                {displayFailedEvacuationsGraph ? (
                    <FailedEvacuationsGraph
                        fromDateTime={fromDateTime}
                        toDateTime={toDateTime}
                    />
                ) : (
                    <div></div>
                )}
            </CardContent>
        </Card>
    );
};

export default Graphs;
