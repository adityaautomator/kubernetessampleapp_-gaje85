import React from 'react';

//project-imports
import Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
import HighchartsReact from 'highcharts-react-official';

//data-imports
import { filterDateTime, failedEvacuationsOptions } from './GraphsData.js';

const FailedEvacuationsGraph = ({ fromDateTime, toDateTime }) => {
    filterDateTime(fromDateTime, toDateTime);
    return (
        // <HighchartsReact
        //     highcharts={Highcharts}
        //     options={failedEvacuationsOptions}
        //     updateArgs={[true]}
        // />
        <p>Failed Evacuations Graph</p>
    );
};

export default FailedEvacuationsGraph;
