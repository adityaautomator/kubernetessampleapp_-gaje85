import React from 'react';

//project-imports
import Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
import HighchartsReact from 'highcharts-react-official';

//data-imports
import { filterDateTime, referenceObjectsOptions } from './GraphsData.js';

const ReferenceObjectsGraph = ({ fromDateTime, toDateTime }) => {
    filterDateTime(fromDateTime, toDateTime);
    return (
        // <HighchartsReact
        //     highcharts={Highcharts}
        //     options={referenceObjectsOptions}
        //     updateArgs={[true]}
        // />
        <p>Reference Objects Graph</p>
    );
};

export default ReferenceObjectsGraph;
