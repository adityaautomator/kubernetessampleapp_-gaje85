import { Select, MenuItem, FormControl, InputLabel } from '@mui/material';
import React, { useState } from 'react';
import { Autocomplete, TextField } from '@mui/material';
import { Navigate, useNavigate } from 'react-router';

const MySelectComponent = () => {
    const navigate = useNavigate();
    const [selectedOption, setSelectedOption] = useState('');

    const handleChange = (event, newValue) => {
        setSelectedOption(newValue);
        console.log(newValue);
        navigate('/summary/certificate');
        navigate(0);
    };

    return (
        <FormControl style={{ width: '15%' }}>
            <Autocomplete
                value={selectedOption}
                onChange={handleChange}
                options={['Fernando Borrero', 'Bryant, Arnold']}
                renderInput={(params) => (
                    <TextField
                        {...params}
                        label="Select User"
                        variant="outlined"
                        style={{ width: '115%'}}
                    />
                )}
            />
        </FormControl>
    );
};

export default MySelectComponent;

