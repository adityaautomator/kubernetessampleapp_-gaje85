import React from 'react'

import { Menu, Layout, Typography } from 'antd';
import { HomeOutlined, AppstoreOutlined, UserOutlined } from '@ant-design/icons';
import './headernav.scss'
import { useNavigate } from 'react-router';
import Selectuser from 'layout/MainLayout/Sidebar/selectUser/selectuser'
const { Header } = Layout;
const { Title } = Typography;





const Index = () => {
    const navigate = useNavigate();

    const redTheme = {
        '@primary-color': '#ff0000', // Red color
    };
    const handleMenuClicksummary = (path) => {
        navigate(path); // Navigate to the specified path
        navigate(0)
    };
    const handleMenuClickdashboard = (path) => {
        navigate(path); // Navigate to the specified path
    };
    return (
        <>
            <Selectuser />
            <Header theme={redTheme}
                style={{
                    display: 'flex',
                    alignItems: 'center',
                    background: '#436a8a'
                }} className='header_bg'>
                {/* <Title level={3} style={{ color: '#fff', float: 'left' }}>
                    Your App
                </Title> */}
                <Menu mode="horizontal" style={{ background: '#436a8a' }} defaultSelectedKeys={['home']} >
                    {/* <Menu.Item key="home" icon={<HomeOutlined />}> */}
                    <Menu.Item key="home" style={{ color: '#fff' }} onClick={() => handleMenuClickdashboard('./dashboard')}>
                        Dashboard
                    </Menu.Item>
                    {/* <Menu.Item key="products" icon={<AppstoreOutlined />}> */}
                    <Menu.Item key="Summarysss" className="menu-item" style={{ color: '#fff' }} onClick={() => handleMenuClicksummary('./summary/certificate')}>
                        Summary
                    </Menu.Item>
                    {/* <Menu.Item key="summary" className="menu-item" style={{ color: '#fff' }}>
                        Summary 1
                    </Menu.Item> */}
                </Menu>
            </Header>
        </>
    )
}

export default Index
