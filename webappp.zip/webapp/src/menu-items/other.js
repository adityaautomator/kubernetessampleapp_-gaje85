// assets
import { IconBrandChrome, IconServer, IconBoxMargin, IconHelp, IconDashboard, IconAperture, IconCode, IconSettingsAutomation, IconDeviceDesktop, IconFileText } from '@tabler/icons';
// import Summary from '../views/summary/summary';
// import { Select } from 'antd';
// constant
const icons = { IconBrandChrome, IconServer, IconBoxMargin, IconHelp, IconDashboard, IconAperture, IconCode, IconSettingsAutomation, IconFileText, IconDeviceDesktop };
// ==============================|| SAMPLE PAGE & DOCUMENTATION MENU ITEMS ||============================== //

const other = {
    id: 'sample-docs-roadmap',
    type: 'group',
    children: [
        // {
        //     id: 'dashboard',
        //     title: 'Dashboard',
        //     type: 'item',
        //     url: '/dashboard',
        //     icon: icons.IconDashboard,
        //     breadcrumbs: false
        // },
        {
            id: 'summary',
            title: 'Summary',
            type: 'item',
            url: '/summary',
            icon: icons.IconAperture,
            external: false,
            // target: true
        },
        {
            id: 'select',
            title: 'Select',
            type: 'collapse',
            icon: icons.IconHelp,
            children: [
                {
                    id: 'option1',
                    title: 'Option 1',
                    type: 'item',
                    url: '/select/option1',
                    icon: icons.IconHelp,
                    external: false,
                },
                {
                    id: 'option2',
                    title: 'Option 2',
                    type: 'item',
                    url: '/select/option2',
                    icon: icons.IconHelp,
                    external: false,
                },
            ]
        },
        // {
        //     id: 'select-component',
        //     title: 'Select Component',
        //     type: 'item',
        //     url: '/select-component',
        //     icon: icons.IconHelp,
        //     external: false,
        // },
        // {
        //     id: 'memory',
        //     title: 'Memory',
        //     type: 'item',
        //     url: '/memory',
        //     icon: icons.IconBoxMargin,
        //     // external: true,
        //     // target: true
        // },

        // {
        //     id: 'code',
        //     title: 'File List',
        //     type: 'item',
        //     url: '/filelist',
        //     icon: icons.IconCode,
        //     external: false,
        //     // target: true
        // },

        // {
        //     id: 'threads',
        //     title: 'Threads',
        //     type: 'item',
        //     url: 'https://codedthemes.gitbook.io/berry/',
        //     icon: icons.IconSettingsAutomation,
        //     external: true,
        //     target: true
        // },
        // {
        //     id: 'io',
        //     title: 'I/O',
        //     type: 'item',
        //     url: 'https://codedthemes.gitbook.io/berry/',
        //     icon: icons.IconServer,
        //     external: true,
        //     target: true
        // },

        // {
        //     id: 'system',
        //     title: 'System',
        //     type: 'item',
        //     url: 'https://codedthemes.gitbook.io/berry/',
        //     icon: icons.IconDeviceDesktop,
        //     external: true,
        //     target: true
        // },

        // {
        //     id: 'events',
        //     title: 'Events',
        //     type: 'item',
        //     url: 'https://codedthemes.gitbook.io/berry/',
        //     icon: icons.IconFileText,
        //     external: true,
        //     target: true
        // },


    ]
};
// const SelectComponent = () => {
//     const handleChange = (selectedOption) => {
//         // Handle the change event here
//     };

//     return (
//         <div>
//             <Select
//                 defaultValue="lucy"
//                 style={{
//                     width: 120,
//                 }}
//                 onChange={handleChange}
//                 options={[
//                     {
//                         value: 'jack',
//                         label: 'Jack',
//                     },
//                     {
//                         value: 'lucy',
//                         label: 'Lucy',
//                     },
//                     {
//                         value: 'Yiminghe',
//                         label: 'yiminghe',
//                     },
//                     {
//                         value: 'disabled',
//                         label: 'Disabled',
//                         disabled: true,
//                     },
//                 ]}
//             />
//         </div>
//     );
// };



export default other ;
