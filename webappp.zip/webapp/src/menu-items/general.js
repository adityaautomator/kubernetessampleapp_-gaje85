// assets
import { IconDashboard } from '@tabler/icons';

// constant
const icons = { IconDashboard };

// ==============================|| Gerneral MENU ITEMS ||============================== //

const general = {
    id: 'general',
    // title: 'Dashboard',
    type: 'group',
    children: [
        {
            id: 'default',
            title: 'General',
            type: 'item',
            url: '/general',
            icon: icons.IconDashboard,
            breadcrumbs: false
        }
    ]
};

export default general;
