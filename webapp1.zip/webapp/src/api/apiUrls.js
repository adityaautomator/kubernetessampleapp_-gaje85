export class ApiUrls {
    // static apiEnvironment = "http://192.168.1.232:4000/mock/"; // local
    // static apiEnvironment = "https://skilingobff.furtimtechnologies.com/"; // node-api
    //static apiJavaEnvironment = "https://skilingoweb.furtimtechnologies.com/"; // java-api


    // =================Sample =========================================
}