import React from 'react';

//project-imports
import Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
import HighchartsReact from 'highcharts-react-official';

//data-imports
import { filterDateTime, heapOptions } from './GraphsData.js';

const HeapGraph = ({ fromDateTime, toDateTime }) => {
    filterDateTime(fromDateTime, toDateTime);
    return (
        <HighchartsReact
            highcharts={Highcharts}
            options={heapOptions}
            updateArgs={[true]}
        />
    );
};

export default HeapGraph;
