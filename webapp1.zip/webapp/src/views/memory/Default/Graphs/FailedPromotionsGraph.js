import React from 'react';

//project-imports
import Highcharts from 'highcharts';
require('highcharts/modules/exporting')(Highcharts);
import HighchartsReact from 'highcharts-react-official';

//data-imports
import { filterDateTime, failedPromotionsOptions } from './GraphsData.js';

const FailedPromotionsGraph = ({ fromDateTime, toDateTime }) => {
    filterDateTime(fromDateTime, toDateTime);
    return (
        // <HighchartsReact
        //     highcharts={Highcharts}
        //     options={failedPromotionsOptions}
        //     updateArgs={[true]}
        // />
        <p>Failed Promotions Graph</p>
    );
};

export default FailedPromotionsGraph;
