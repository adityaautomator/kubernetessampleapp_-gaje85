import FailedPromotionsGraph from './FailedPromotionsGraph';

var date = new Date();

var weakReferencesObject = {
    name: 'Weak References',
    color: 'rgb(0,0,255)',
    data: [
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                8,
                0,
                0
            ),
            y: 300
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                12,
                0,
                0
            ),
            y: 800
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                17,
                0,
                0
            ),
            y: 400
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                18,
                0,
                0
            ),
            y: 1200
        }
    ]
};

var softReferencesObject = {
    name: 'Soft References',
    color: 'rgb(255, 255, 0)',
    data: [
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                8,
                0,
                0
            ),
            y: 100
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                9,
                0,
                0
            ),
            y: 600
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                14,
                0,
                0
            ),
            y: 300
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                18,
                0,
                0
            ),
            y: 900
        }
    ]
};

var finalReferencesObject = {
    name: 'Final References',
    color: 'rgb(255, 0, 0)',
    data: [
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                8,
                0,
                0
            ),
            y: 1200
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                10,
                0,
                0
            ),
            y: 300
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                11,
                0,
                0
            ),
            y: 100
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                18,
                0,
                0
            ),
            y: 400
        }
    ]
};

var phantomReferencesObject = {
    name: 'Phantom References',
    color: 'rgb(0, 0, 0)',
    data: [
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                8,
                0,
                0
            ),
            y: 100
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                14,
                0,
                0
            ),
            y: 500
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                15,
                0,
                0
            ),
            y: 300
        },
        {
            x: Date.UTC(
                date.getFullYear(),
                date.getMonth(),
                date.getDate(),
                18,
                0,
                0
            ),
            y: 700
        }
    ]
};

var seriesData = [];

const filterDateTime = (fromDateTime, toDateTime) => {
    seriesData.length = 0;

    let newSeriesData = [];
    let fromDateTimeValue = new Date(fromDateTime);
    let toDateTimeValue = new Date(toDateTime);

    weakReferencesObject.data.forEach((point) => {
        if (point != null) {
            let pointDateValue = new Date(point.x);
            let dateValue = new Date(
                pointDateValue.getTime() +
                    pointDateValue.getTimezoneOffset() * 60000
            );
            if (
                dateValue >= fromDateTimeValue &&
                dateValue <= toDateTimeValue
            ) {
                newSeriesData.push(point);
            } else {
                newSeriesData.push(null);
            }
        }
    });
    weakReferencesObject.data = [];
    weakReferencesObject.data = newSeriesData;
    newSeriesData = [];

    softReferencesObject.data.forEach((point) => {
        if (point != null) {
            let pointDateValue = new Date(point.x);
            let dateValue = new Date(
                pointDateValue.getTime() +
                    pointDateValue.getTimezoneOffset() * 60000
            );
            if (
                dateValue >= fromDateTimeValue &&
                dateValue <= toDateTimeValue
            ) {
                newSeriesData.push(point);
            } else {
                newSeriesData.push(null);
            }
        }
    });
    softReferencesObject.data = [];
    softReferencesObject.data = newSeriesData;
    newSeriesData = [];

    finalReferencesObject.data.forEach((point) => {
        if (point != null) {
            let pointDateValue = new Date(point.x);
            let dateValue = new Date(
                pointDateValue.getTime() +
                    pointDateValue.getTimezoneOffset() * 60000
            );
            if (
                dateValue >= fromDateTimeValue &&
                dateValue <= toDateTimeValue
            ) {
                newSeriesData.push(point);
            } else {
                newSeriesData.push(null);
            }
        }
    });
    finalReferencesObject.data = [];
    finalReferencesObject.data = newSeriesData;
    newSeriesData = [];

    phantomReferencesObject.data.forEach((point) => {
        if (point != null) {
            let pointDateValue = new Date(point.x);
            let dateValue = new Date(
                pointDateValue.getTime() +
                    pointDateValue.getTimezoneOffset() * 60000
            );
            if (
                dateValue >= fromDateTimeValue &&
                dateValue <= toDateTimeValue
            ) {
                newSeriesData.push(point);
            } else {
                newSeriesData.push(null);
            }
        }
    });
    phantomReferencesObject.data = [];
    phantomReferencesObject.data = newSeriesData;
    newSeriesData = [];

    seriesData.push(weakReferencesObject);
    seriesData.push(softReferencesObject);
    seriesData.push(finalReferencesObject);
    seriesData.push(phantomReferencesObject);
};

const heapOptions = {
    chart: {
        type: 'area'
    },
    accessibility: {
        enabled: false
    },
    credits: {
        enabled: false
    },
    title: {
        text: 'Heap Graph'
    },
    xAxis: {
        allowDecimals: false,
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        title: {
            text: 'Time'
        },
        type: 'datetime',
        labels: {
            format: '{value:%H:%M:%S}'
        },
        min: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            8,
            0,
            0
        ),
        max: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            18,
            0,
            0
        )
    },
    yAxis: {
        title: {
            text: 'Count'
        },
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        min: 0
    },
    plotOptions: {
        area: {
            marker: {
                enabled: false,
                symbol: 'circle',
                radius: 5,
                states: {
                    hover: {
                        enabled: true
                    }
                }
            }
        }
    },
    series: seriesData
};

const referenceObjectsOptions = {
    chart: {
        type: 'area'
    },
    accessibility: {
        enabled: false
    },
    credits: {
        enabled: false
    },
    title: {
        text: 'Reference Objects Graph'
    },
    xAxis: {
        allowDecimals: false,
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        title: {
            text: 'Time'
        },
        type: 'datetime',
        labels: {
            format: '{value:%H:%M:%S}'
        },
        min: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            8,
            0,
            0
        ),
        max: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            18,
            0,
            0
        )
    },
    yAxis: {
        title: {
            text: 'Count'
        },
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        min: 0
    },
    plotOptions: {
        area: {
            marker: {
                enabled: false,
                symbol: 'circle',
                radius: 5,
                states: {
                    hover: {
                        enabled: true
                    }
                }
            }
        }
    },
    series: seriesData
};

const failedEvacuationsOptions = {
    chart: {
        type: 'area'
    },
    accessibility: {
        enabled: false
    },
    credits: {
        enabled: false
    },
    title: {
        text: 'Failed Evacuations Graph'
    },
    xAxis: {
        allowDecimals: false,
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        title: {
            text: 'Time'
        },
        type: 'datetime',
        labels: {
            format: '{value:%H:%M:%S}'
        },
        min: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            8,
            0,
            0
        ),
        max: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            18,
            0,
            0
        )
    },
    yAxis: {
        title: {
            text: 'Count'
        },
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        min: 0
    },
    plotOptions: {
        area: {
            marker: {
                enabled: false,
                symbol: 'circle',
                radius: 5,
                states: {
                    hover: {
                        enabled: true
                    }
                }
            }
        }
    },
    series: seriesData
};

const failedPromotionsOptions = {
    chart: {
        type: 'area'
    },
    accessibility: {
        enabled: false
    },
    credits: {
        enabled: false
    },
    title: {
        text: 'Failed Promotions Graph'
    },
    xAxis: {
        allowDecimals: false,
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        title: {
            text: 'Time'
        },
        type: 'datetime',
        labels: {
            format: '{value:%H:%M:%S}'
        },
        min: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            8,
            0,
            0
        ),
        max: Date.UTC(
            date.getFullYear(),
            date.getMonth(),
            date.getDate(),
            18,
            0,
            0
        )
    },
    yAxis: {
        title: {
            text: 'Count'
        },
        gridLineWidth: 1,
        gridLineDashStyle: 'longdash',
        min: 0
    },
    plotOptions: {
        area: {
            marker: {
                enabled: false,
                symbol: 'circle',
                radius: 5,
                states: {
                    hover: {
                        enabled: true
                    }
                }
            }
        }
    },
    series: seriesData
};

export {
    filterDateTime,
    heapOptions,
    referenceObjectsOptions,
    failedEvacuationsOptions,
    failedPromotionsOptions
};
