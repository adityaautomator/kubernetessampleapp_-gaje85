import React, { useState, useEffect } from 'react';

// material-ui
import { FormControlLabel, Checkbox, Card, CardContent } from '@mui/material';

const AvailableOptions = ({ handleCheckBoxesSelected }) => {
    const [heapChecked, setHeapChecked] = useState(true);
    const [referenceObjectsChecked, setReferenceObjectsChecked] =
        useState(true);
    const [failedPromotionsChecked, setFailedPromotionsChecked] =
        useState(true);
    const [failedEvacuationsChecked, setFailedEvacuationsChecked] =
        useState(true);

    const handleChange = (checkbox) => {
        if (checkbox === 'Heap') {
            setHeapChecked(!heapChecked);
        } else if (checkbox === 'Reference Objects') {
            setReferenceObjectsChecked(!referenceObjectsChecked);
        } else if (checkbox === 'Failed Promotions') {
            setFailedPromotionsChecked(!failedPromotionsChecked);
        } else if (checkbox === 'Failed Evacuations') {
            setFailedEvacuationsChecked(!failedEvacuationsChecked);
        }
    };

    useEffect(() => {
        selectedCheckBoxesUpdate();
    }, [
        heapChecked,
        referenceObjectsChecked,
        failedPromotionsChecked,
        failedEvacuationsChecked
    ]);

    const selectedCheckBoxesUpdate = () => {
        let slctdChkBxs = [];
        if (heapChecked) {
            slctdChkBxs.push('Heap');
        }
        if (referenceObjectsChecked) {
            slctdChkBxs.push('Reference Objects');
        }
        if (failedPromotionsChecked) {
            slctdChkBxs.push('Failed Promotions');
        }
        if (failedEvacuationsChecked) {
            slctdChkBxs.push('Failed Evacuations');
        }

        handleCheckBoxesSelected(slctdChkBxs);
    };

    return (
        <Card
            sx={{
                mt: 5
            }}
        >
            <CardContent>
                <FormControlLabel
                    sx={{
                        mr: 3,
                        ml: 1
                    }}
                    control={
                        <Checkbox
                            checked={heapChecked}
                            onChange={() => handleChange('Heap')}
                        />
                    }
                    label="Heap"
                />
                <FormControlLabel
                    control={
                        <Checkbox
                            checked={referenceObjectsChecked}
                            onChange={() => handleChange('Reference Objects')}
                        />
                    }
                    label="Reference Objects"
                />
                <FormControlLabel
                    control={
                        <Checkbox
                            checked={failedPromotionsChecked}
                            onChange={() => handleChange('Failed Promotions')}
                        />
                    }
                    label="Failed Promotions"
                />
                <FormControlLabel
                    control={
                        <Checkbox
                            checked={failedEvacuationsChecked}
                            onChange={() => handleChange('Failed Evacuations')}
                        />
                    }
                    label="Failed Evacuations"
                />
            </CardContent>
        </Card>
    );
};

export default AvailableOptions;
