import React, { useState } from 'react';

// material-ui
import { Grid, Box } from '@mui/material';

// project imports
import { gridSpacing } from 'store/constant';
import AvailableOptions from './AvailableOptions';
import { DateTimeFromPicker, DateTimeToPicker } from './DateTimePicker';
import Graphs from './Graphs/Graphs';

var today = new Date();
var todayDateString =
    today.getFullYear() +
    '-' +
    ('0' + (today.getMonth() + 1)).slice(-2) +
    '-' +
    ('0' + today.getDate()).slice(-2);

const Memory = () => {
    const [selectedCheckBoxes, setSelectedCheckBoxes] = useState([
        'Heap',
        'Reference Objects',
        'Failed Promotions',
        'Failed Evacuations'
    ]);
    const handleCheckBoxesSelected = (slctdChkBxs) => {
        setSelectedCheckBoxes(slctdChkBxs);
    };

    const [selectedDateTimeFrom, setSelectedDateTimeFrom] = useState(
        todayDateString + 'T07:59:59'
    );
    const handleDateTimeFromSelected = (slctdDtTmFr) => {
        setSelectedDateTimeFrom(slctdDtTmFr);
    };

    const [selectedDateTimeTo, setSelectedDateTimeTo] = useState(
        todayDateString + 'T18:00:01'
    );
    const handleDateTimeToSelected = (slctdDtTmTo) => {
        setSelectedDateTimeTo(slctdDtTmTo);
    };

    return (
        <Box>
            <Grid
                container
                spacing={gridSpacing}
                justifyContent="center"
            >
                <DateTimeFromPicker
                    todayDateString={todayDateString}
                    handleDateTimeFromSelected={handleDateTimeFromSelected}
                />
                <DateTimeToPicker
                    todayDateString={todayDateString}
                    handleDateTimeToSelected={handleDateTimeToSelected}
                />
            </Grid>
            <Grid
                container
                spacing={gridSpacing}
                justifyContent="center"
            >
                <AvailableOptions
                    handleCheckBoxesSelected={handleCheckBoxesSelected}
                />
            </Grid>
            <Grid
                container
                spacing={gridSpacing}
                justifyContent="center"
            >
                <Graphs
                    graphsToDisplay={selectedCheckBoxes}
                    fromDateTime={selectedDateTimeFrom}
                    toDateTime={selectedDateTimeTo}
                />
            </Grid>
        </Box>
    );
};

export default Memory;
